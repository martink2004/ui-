# Towns for SoftUni Svetlina
For exercise for students in the "Software Engineering" course
